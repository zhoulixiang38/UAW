#!/bin/bash

set -e
set -x

CUDA_VISIBLE_DEVICES=0 python traindaamean.py \
    --dataset_name 'cifar10' \
    --batch_size 32 \
    --epochs 100 \
    --prop_train_labels 0.5 \
    --num_workers 6 \
    --sup_weight 0.35 \
    --weight_decay 5e-5 \
    --memax_weight 1 \
    --exp_name 0.5dalishi-daa
