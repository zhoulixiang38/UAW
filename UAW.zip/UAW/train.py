import argparse
import torch.nn.functional as F
import math
import numpy as np
import torch
import os
import torch.nn as nn
from torch.optim import SGD, lr_scheduler
from torch.utils.data import DataLoader
from tqdm import tqdm
from uti import MarginLoss
from data.augmentations import get_transform
from data.get_datasets import get_datasets, get_class_splits
from torch.utils.tensorboard import SummaryWriter
from util.general_utils import AverageMeter, init_experiment
from util.cluster_and_log_utils import log_accs_from_preds
from model import DINOHead, info_nce_logits, SupConLoss, DistillLoss, ContrastiveLearningViewGenerator, get_params_groups
from torch.nn import init
import copy


class DynamicAttentionAdjustment(nn.Module):
    def __init__(self, channels: int, groups: int):
        super().__init__()
        self.channels = channels
        self.groups = groups
        
        if channels % groups != 0:
            raise ValueError(f"Number of channels ({channels}) must be divisible by number of groups ({groups}).")
        self.global_avg_pool = nn.AdaptiveAvgPool2d(1)
        self.ffnn = nn.Sequential(
            nn.Linear(channels, channels // 2),  
            nn.ReLU(inplace=True),
            nn.Linear(channels // 2, groups),    
            nn.Sigmoid()                         
        )
        
        self.sigmoid_activation = nn.Sigmoid()

        self.init_weights()

    def init_weights(self):
        for m in self.ffnn.modules():
            if isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, std=0.001) 
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0) 

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, c, h, w = x.shape
        global_feature_vector = self.global_avg_pool(x).squeeze(-1).squeeze(-1)
        omega = self.ffnn(global_feature_vector) 

        x_grouped = x.view(b, self.groups, c // self.groups, h, w)

        avg_per_group = x_grouped.mean(dim=(-1, -2)) 
        dynamic_global_semantic_vectors = omega.unsqueeze(-1) * avg_per_group 
        
        c_g_i = torch.sum(x_grouped * dynamic_global_semantic_vectors.unsqueeze(-1).unsqueeze(-1), dim=2)
        
        mu_c = c_g_i.mean(dim=(-1, -2), keepdim=True)         
        sigma_c = c_g_i.std(dim=(-1, -2), keepdim=True) + 1e-5 
        hat_c_g_i = (c_g_i - mu_c) / sigma_c                 
        
        attention_weights = self.sigmoid_activation(hat_c_g_i) 
        attention_weights_broadcast = attention_weights.unsqueeze(2)
        
        enhanced_x_grouped = x_grouped * attention_weights_broadcast 
        
        final_output = enhanced_x_grouped.view(b, c, h, w)
        return final_output


def train(student, teacher_model, train_loader, test_loader, unlabelled_train_loader, args, m, current_epoch, tf_writer, daa_module):
    global best_test_acc_lab, best_test_acc_ubl, best_test_acc_all
    global best_train_acc_lab, best_train_acc_ubl, best_train_acc_all
    
    params_groups = get_params_groups(student)
    optimizer = SGD(params_groups, lr=args.lr, momentum=args.momentum, weight_decay=args.weight_decay)
    
    fp16_scaler = None
    if args.fp16:
        fp16_scaler = torch.cuda.amp.GradScaler()

    exp_lr_scheduler = lr_scheduler.CosineAnnealingLR(
            optimizer,
            T_max=args.epochs,
            eta_min=args.lr * 1e-3,
        )

    ce = MarginLoss(m=-1 * m)
    cluster_criterion = DistillLoss(
                        args.warmup_teacher_temp_epochs,
                        args.epochs,
                        args.n_views,
                        args.warmup_teacher_temp,
                        args.teacher_temp,
                    )
    
    for _ in range(1): 
        loss_record = AverageMeter()
        student.train()
        teacher_model.eval() 

        for batch_idx, batch in enumerate(train_loader):
            images_list, class_labels, uq_idxs, mask_lab = batch
            mask_lab = mask_lab[:, 0] 

            class_labels, mask_lab = class_labels.cuda(non_blocking=True), mask_lab.cuda(non_blocking=True).bool()
            
            images_student_v1_input = images_list[0].cuda(non_blocking=True)
            images_student_v2_input = images_list[1].cuda(non_blocking=True)
            images_teacher_v_strong_input = images_list[1].cuda(non_blocking=True)

            images_student_v1_daa = daa_module(images_student_v1_input)
            images_student_v2_daa = daa_module(images_student_v2_input)
            images_teacher_v_strong_daa = daa_module(images_teacher_v_strong_input)

            with torch.cuda.amp.autocast(fp16_scaler is not None):
                s_feat_v1, s_out_v1 = student(images_student_v1_daa)
                s_feat_v2, s_out_v2 = student(images_student_v2_daa) 

                t_feat_v_strong, t_out_v_strong = teacher_model(images_teacher_v_strong_daa)
                t_feat_v_strong = t_feat_v_strong.detach()
                t_out_v_strong = t_out_v_strong.detach()

                sup_logits = (s_out_v1[mask_lab] / 0.1) 
                sup_labels = class_labels[mask_lab] 
                cls_loss = ce(sup_logits, sup_labels)

                cluster_loss = cluster_criterion(s_out_v1, t_out_v_strong, current_epoch)
                
                avg_probs = (s_out_v1 / 0.1).softmax(dim=1).mean(dim=0)
                me_max_loss = - torch.sum(torch.log(avg_probs**(-avg_probs))) + math.log(float(len(avg_probs)))
                cluster_loss += args.memax_weight * me_max_loss

                contrastive_features_LU = torch.cat([s_feat_v1, t_feat_v_strong], dim=0)
                contrastive_logits, contrastive_labels = info_nce_logits(features=contrastive_features_LU)
                contrastive_loss = torch.nn.CrossEntropyLoss()(contrastive_logits, contrastive_labels)

                student_proj_LS = torch.stack([s_feat_v1[mask_lab], s_feat_v2[mask_lab]], dim=1)
                student_proj_LS = torch.nn.functional.normalize(student_proj_LS, dim=-1)
                sup_con_labels = class_labels[mask_lab]
                sup_con_loss = SupConLoss()(student_proj_LS, labels=sup_con_labels)

                pstr = ''
                pstr += f'cls_loss: {cls_loss.item():.4f} '
                pstr += f'cluster_loss: {cluster_loss.item():.4f} '
                pstr += f'sup_con_loss: {sup_con_loss.item():.4f} '
                pstr += f'contrastive_loss: {contrastive_loss.item():.4f} '

                loss = (1 - args.sup_weight) * cluster_loss + args.sup_weight * cls_loss
                loss += (1 - args.sup_weight) * contrastive_loss + args.sup_weight * sup_con_loss
                
            loss_record.update(loss.item(), class_labels.size(0))
            optimizer.zero_grad()
            if fp16_scaler is None:
                loss.backward()
                optimizer.step()
            else:
                fp16_scaler.scale(loss).backward()
                fp16_scaler.step(optimizer)
                fp16_scaler.update()

            with torch.no_grad():
                for student_param, teacher_param in zip(student.parameters(), teacher_model.parameters()):
                    teacher_param.data.mul_(args.ema_decay).add_(student_param.data, alpha=1 - args.ema_decay)

            if batch_idx % args.print_freq == 0:
                args.logger.info('epoch: [{}][{}/{}]\t loss {:.5f}\t {}'
                            .format(current_epoch, batch_idx, len(train_loader), loss.item(), pstr))
        
        args.logger.info('Train Epoch: {} Avg Loss: {:.4f} '.format(current_epoch, loss_record.avg))
        tf_writer.add_scalar('record/loss',loss_record.avg, current_epoch)
        
        exp_lr_scheduler.step()

        save_dict = {
            'student_model': student.state_dict(),
            'teacher_model': teacher_model.state_dict(),
            'optimizer': optimizer.state_dict(),
            'epoch': current_epoch + 1,
        }
        torch.save(save_dict, args.model_path)
        args.logger.info(f"Model saved to {args.model_path}.")


def trt(args, model, device, test_loader_unlabelled, daa_module):
    model.eval()
    preds = np.array([])
    confs = np.array([])
    daa_module.eval()

    with torch.no_grad():
        for batch_idx, (x, _,_) in enumerate(test_loader_unlabelled):
            x = x.to(device)
            images_daa = daa_module(x) 
            output, _ = model(images_daa) 

            prob = F.softmax(output, dim=1)
            conf, pred = prob.max(1)
            
            preds = np.append(preds, pred.cpu().numpy())
            confs = np.append(confs, conf.cpu().numpy())
            
    mean_uncert = 1 - np.mean(confs)
    
    return mean_uncert
   
def test(model, test_loader, epoch, save_name, args, daa_module):
    model.eval()
    preds, targets, features_collect = [], [], []
    mask = np.array([])
    with torch.no_grad():
        for batch_idx, (images, label, _) in enumerate(tqdm(test_loader)):
            images = images.cuda(non_blocking=True)
            images_daa = daa_module(images) 
            features, logits = model(images_daa)
            preds.append(logits.argmax(1).cpu().numpy())
            targets.append(label.cpu().numpy())
            features_collect.append(features.cpu().numpy())
            mask = np.append(mask, np.array([True if x.item() in range(len(args.train_classes)) else False for x in label]))

    preds = np.concatenate(preds)
    targets = np.concatenate(targets)
    features_collect = np.concatenate(features_collect, axis=0)
    all_acc, old_acc, new_acc = log_accs_from_preds(y_true=targets, y_pred=preds, mask=mask,
                                                    T=epoch, eval_funcs=args.eval_funcs, save_name=save_name,
                                                    args=args)

    return all_acc, old_acc, new_acc, features_collect, targets


if __name__ == "__main__":

    parser = argparse.ArgumentParser(description='cluster', formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--batch_size', default=128, type=int)
    parser.add_argument('--num_workers', default=8, type=int)
    parser.add_argument('--eval_funcs', nargs='+', default=['v2', 'v2'])
    parser.add_argument('--ep', default=1, type=int)
    parser.add_argument('--warmup_model_dir', type=str, default=None)
    parser.add_argument('--dataset_name', type=str, default='cifar10', help='options: cifar10,ccl2,NEU,tilda2,dagm12,dagm2,tilda5')
    parser.add_argument('--prop_train_labels', type=float, default=0.5)
    parser.add_argument('--grad_from_block', type=int, default=11)
    parser.add_argument('--lr', type=float, default=0.1)
    parser.add_argument('--gamma', type=float, default=0.1)
    parser.add_argument('--momentum', type=float, default=0.9)
    parser.add_argument('--weight_decay', type=float, default=1e-4)
    parser.add_argument('--epochs', default=100, type=int)
    parser.add_argument('--exp_root', type=str, default='/home/featurize/work/UAW/outputs')
    parser.add_argument('--transform', type=str, default='imagenet')
    parser.add_argument('--sup_weight', type=float, default=0.35)
    parser.add_argument('--n_views', default=2, type=int)
    
    parser.add_argument('--memax_weight', type=float, default=2)
    parser.add_argument('--warmup_teacher_temp', default=0.07, type=float, help='Initial value for the teacher temperature.')
    parser.add_argument('--teacher_temp', default=0.04, type=float, help='Final value (after linear warmup)of the teacher temperature.')
    parser.add_argument('--warmup_teacher_temp_epochs', default=30, type=int, help='Number of warmup epochs for the teacher temperature.')
    parser.add_argument('--ema_decay', default=0.999, type=float, help='EMA decay rate for teacher model.')

    parser.add_argument('--fp16', action='store_true', default=False)
    parser.add_argument('--print_freq', default=10, type=int)
    parser.add_argument('--exp_name', default=None, type=str)

    args = parser.parse_args()
    device = torch.device('cuda:0')
    args = get_class_splits(args)
    args.savedir = os.path.join(args.exp_root, args.exp_name)
    if not os.path.exists(args.savedir):
        os.makedirs(args.savedir)
    args.num_labeled_classes = len(args.train_classes)
    args.num_unlabeled_classes = len(args.unlabeled_classes)

    init_experiment(args, runner_name=['UAW'])
    args.logger.info(f'Using evaluation function {args.eval_funcs[0]} to print results')
    
    torch.backends.cudnn.benchmark = True

    args.interpolation = 3
    args.crop_pct = 0.875

    # Define model-related hyperparameters here, BEFORE DINOHead and DataLoaders are initialized
    args.image_size = 224
    args.feat_dim = 768 # ViT-B/16 feature dimension
    args.num_mlp_layers = 3 # DINOHead MLP layers
    args.mlp_out_dim = args.num_labeled_classes + args.num_unlabeled_classes # Total classes for output

    # Get data transformations
    train_transform, test_transform = get_transform(args.transform, image_size=args.image_size, args=args)
    train_transform = ContrastiveLearningViewGenerator(base_transform=train_transform, n_views=args.n_views)

    # Get datasets and dataloaders
    train_dataset, test_dataset, unlabelled_train_examples_test, datasets = get_datasets(args.dataset_name,train_transform,test_transform,args)

    label_len = len(train_dataset.labelled_dataset)
    unlabelled_len = len(train_dataset.unlabelled_dataset)
    sample_weights = [1 if i < label_len else label_len / unlabelled_len for i in range(len(train_dataset))]
    sample_weights = torch.DoubleTensor(sample_weights)
    sampler = torch.utils.data.WeightedRandomSampler(sample_weights, num_samples=len(train_dataset))

    train_loader = DataLoader(train_dataset, num_workers=args.num_workers, batch_size=args.batch_size, shuffle=False,
                              sampler=sampler, drop_last=True, pin_memory=True)
    test_loader_unlabelled = DataLoader(unlabelled_train_examples_test, num_workers=args.num_workers,
                                        batch_size=256, shuffle=False, pin_memory=False)
    test_loader = DataLoader(test_dataset, num_workers=args.num_workers,
                                      batch_size=256, shuffle=False, pin_memory=False)
    
    args.logger.info('DataLoaders initialized.')

    student_backbone = torch.hub.load('facebookresearch/dino:main', 'dino_vitb16')

    if args.warmup_model_dir is not None:
        args.logger.info(f'Loading weights from {args.warmup_model_dir} for student backbone')
        state_dict_backbone = torch.load(args.warmup_model_dir, map_location=device)
        student_backbone.load_state_dict(state_dict_backbone)
    
    for m in student_backbone.parameters():
        m.requires_grad = False
    for name, m in student_backbone.named_parameters():
        if 'block' in name:
            block_num = int(name.split('.')[1])
            if block_num >= args.grad_from_block:
                m.requires_grad = True

    student_projector = DINOHead(in_dim=args.feat_dim, out_dim=args.mlp_out_dim, nlayers=args.num_mlp_layers)
    student_model = nn.Sequential(student_backbone, student_projector).to(device)
    args.logger.info('Student model initialized.')

    teacher_backbone = torch.hub.load('facebookresearch/dino:main', 'dino_vitb16')
    teacher_projector = DINOHead(in_dim=args.feat_dim, out_dim=args.mlp_out_dim, nlayers=args.num_mlp_layers)
    teacher_model = nn.Sequential(teacher_backbone, teacher_projector).to(device)
    
    teacher_model.load_state_dict(student_model.state_dict())
    
    for param in teacher_model.parameters():
        param.requires_grad = False
    
    args.logger.info('Teacher model initialized and parameters frozen.')

    daa_module = DynamicAttentionAdjustment(channels=3, groups=3).to(device)
    args.logger.info('Dynamic Attention Adjustment (DAA) module initialized.')

    best_test_acc_lab = 0
    best_test_acc_ubl = 0 
    best_test_acc_all = 0
    best_train_acc_lab = 0
    best_train_acc_ubl = 0 
    best_train_acc_all = 0
    
    tf_writer = SummaryWriter(log_dir=args.savedir)

    for epoch in range(args.epochs):
        mean_uncert = trt(args, student_model, device, test_loader_unlabelled, daa_module) 
        
        args.logger.info(f"Starting Epoch {epoch}/{args.epochs} (Uncertainty Margin m: {mean_uncert:.4f})")
        train(student_model, teacher_model, train_loader, test_loader, test_loader_unlabelled, args, mean_uncert, epoch, tf_writer, daa_module)

        args.logger.info('Evaluating on unlabelled examples in the training data...')
        all_acc, old_acc, new_acc, _, _ = test(student_model, test_loader_unlabelled, epoch=epoch, save_name='Train ACC Unlabelled', args=args, daa_module=daa_module)
        args.logger.info('Evaluating on disjoint test set...')
        all_acc_test, old_acc_test, new_acc_test, _, _ = test(student_model, test_loader, epoch=epoch, save_name='Test ACC', args=args, daa_module=daa_module)
        
        tf_writer.add_scalar('acc/train_all', all_acc, epoch)
        tf_writer.add_scalar('acc/train_old', old_acc, epoch)
        tf_writer.add_scalar('acc/train_new', new_acc, epoch)
        tf_writer.add_scalar('acc/test_all', all_acc_test, epoch)
        tf_writer.add_scalar('acc/test_old', old_acc_test, epoch)
        tf_writer.add_scalar('acc/test_new', new_acc_test, epoch)

        args.logger.info('Train Accuracies: All {:.4f} | Old {:.4f} | New {:.4f}'.format(all_acc, old_acc, new_acc))
        args.logger.info('Test Accuracies: All {:.4f} | Old {:.4f} | New {:.4f}'.format(all_acc_test, old_acc_test, new_acc_test))
        
        if all_acc_test > best_test_acc_all:
            save_dict_best_test = {
                'student_model': student_model.state_dict(),
                'teacher_model': teacher_model.state_dict(),
                'optimizer': None,
                'epoch': epoch + 1,
            }
            torch.save(save_dict_best_test, os.path.join(args.savedir, 'model_best.pt'))
            args.logger.info(f"New best test model saved to {os.path.join(args.savedir, 'model_best.pt')}.")
            best_test_acc_lab = old_acc_test
            best_test_acc_ubl = new_acc_test
            best_test_acc_all = all_acc_test
        args.logger.info(f'Exp Name: {args.exp_name}')
        args.logger.info(f'Metrics with best model on test set: All: {best_test_acc_all:.4f} Old: {best_test_acc_lab:.4f} New: {best_test_acc_ubl:.4f}')

        if all_acc > best_train_acc_all:
            save_dict_best_train = {
                'student_model': student_model.state_dict(),
                'teacher_model': teacher_model.state_dict(),
                'optimizer': None,
                'epoch': epoch + 1,
            }
            torch.save(save_dict_best_train, os.path.join(args.savedir, 'model_best_train_unlabelled.pt'))
            args.logger.info(f"New best train (unlabelled) model saved to {os.path.join(args.savedir, 'model_best_train_unlabelled.pt')}.")
            best_train_acc_lab = old_acc
            best_train_acc_ubl = new_acc
            best_train_acc_all = all_acc
        args.logger.info(f'Exp Name: {args.exp_name}')
        args.logger.info(f'Metrics with best model on train (unlabelled) set: All: {best_train_acc_all:.4f} Old: {best_train_acc_lab:.4f} New: {best_train_acc_ubl:.4f}')

